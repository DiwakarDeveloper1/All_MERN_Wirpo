import Data from "./Data/Data"
function App() {
  return (
    <div>
      <Data/>
    </div>
  );
}

export default App;
