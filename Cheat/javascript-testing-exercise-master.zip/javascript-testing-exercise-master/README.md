## Unit Testing Exercise

In this exercise you need to write test cases for the functions written in `script.js` file. Read the comments written in `script.spec.js` file for each test case and write the code accordingly.