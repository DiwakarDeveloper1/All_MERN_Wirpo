import Contact from "./Contact/Contact"
function App() {
  return (
    <Contact />
  );
}

export default App;
