# Make an application with *‘create-react-app’*

### 1. Create a new project with 'create-react-app' with appropriate commands.
### 2. Once the project is made, remove all the default code provided and start with a clean slate to make your own components.
### 3. Make 3 or more separate components in different files.
### 4. Import all the components wherever required, and make a simple portfolio, which shows the details like - Image, Past Experience, Professional Summary, etc.

![Make an application with *‘create-react-app’*](https://gitlab-wipro.stackroute.in/mern-react-boilerplates/crs-sur-1030/react-first-app-practice/-/raw/master/S114-P2_v1.png)
