const Summary = () => {
    return (
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Summary</h1>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia reprehenderit rem labore, facere, maiores quo eum, laudantium perferendis consequuntur officia veritatis assumenda aperiam dignissimos alias ratione hic repellendus fugit. Maxime.
                        Quidem pariatur velit libero, soluta nemo exercitationem iste quis tempore eaque sunt numquam! Fuga quia alias voluptatem cupiditate! Aperiam mollitia, rerum accusantium saepe ipsa at? Quam, quae? Repudiandae, facere harum.</p>
                </div>
            </div>
        </div>
    )
}
export default Summary;