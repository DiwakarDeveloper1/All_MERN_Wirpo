import Navbar1 from "./Navbar1/Navbar1";
import Banner from "./Banner/Banner";
import Card1 from "./Card1/Card1"; 
import Footer1 from "./Footer1/Footer1";
function App() {
  return (
    <div>
      <Navbar1 />
      <Banner />
      <Card1 />
      <Footer1 />
    </div>

  );
}

export default App;
