import Event from "./Event/Event";
function App() {
  return (
    <div>
      <Event />
    </div>
  );
}

export default App;
