import React from 'react'
import Header from "./Header/Header"
import Home from "./Home/Home"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Bookdetails from "./Bookdetails/Bookdetails"
const Addbook = React.lazy(() => import("./Addbook/Addbook"));   //Lazy loading component
const Managebook = React.lazy(() => import("./Managebook/Managebook"));   //Lazy loading component
function App() {
 
  return (
    <div>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/add-books" element={<Addbook />} />
          <Route path="/manage-books" element={<Managebook />} />
          <Route path="/manage-books/:id" element={<Bookdetails />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
